import type { WebsiteStatus } from "@/lib/types";

const STYLES: Record<WebsiteStatus, { text: string; cls: string }> = {
  none: { text: "No website listed", cls: "border-amber-400/60 bg-amber-400/10 text-amber-400" },
  verify: { text: "Needs verification", cls: "border-brick-400/60 bg-brick-400/10 text-brick-400" },
  found: { text: "Website found", cls: "border-sage-400/50 bg-sage-400/10 text-sage-400" }
};

export default function StatusBadge({ status }: { status: WebsiteStatus }) {
  const s = STYLES[status];
  return (
    <span className={`inline-block rounded-full border px-2.5 py-0.5 text-sm font-semibold ${s.cls}`}>
      {s.text}
    </span>
  );
}
