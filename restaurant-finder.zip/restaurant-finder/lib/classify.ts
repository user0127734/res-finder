import type { WebsiteStatus } from "./types";

const SOCIAL = /(facebook\.com|fb\.com|instagram\.com|yelp\.com|tripadvisor\.|twitter\.com|x\.com|tiktok\.com|linktr\.ee|linktree|doordash\.com|ubereats\.com|grubhub\.com|menupages|opentable\.com|google\.com\/maps|goo\.gl|business\.site)/i;

/**
 * Decide the website status from what the data provider gave us.
 * A missing field is NOT proof that no website exists, so "none" really means "no website listed".
 */
export function classifyWebsite(
  website: string | undefined,
  socialOnly: boolean
): { status: WebsiteStatus; note: string; url: string } {
  const raw = (website || "").trim();
  if (!raw) {
    if (socialOnly) {
      return {
        status: "verify",
        note: "Only a social media or listing page is recorded. Check whether they have their own site.",
        url: ""
      };
    }
    return { status: "none", note: "No website listed in the data. Verify before contacting.", url: "" };
  }
  const withProto = /^https?:\/\//i.test(raw) ? raw : `https://${raw}`;
  let host = "";
  try {
    host = new URL(withProto).hostname;
  } catch {
    return { status: "verify", note: "The listed website address looks invalid.", url: raw };
  }
  if (!host.includes(".")) {
    return { status: "verify", note: "The listed website address looks incomplete.", url: raw };
  }
  if (SOCIAL.test(withProto)) {
    return {
      status: "verify",
      note: "Listed link is a social media or listing page, not their own website.",
      url: withProto
    };
  }
  return { status: "found", note: "A website is listed.", url: withProto };
}
