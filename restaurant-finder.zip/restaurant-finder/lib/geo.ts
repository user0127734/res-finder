export function haversineMiles(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const R = 3958.8;
  const toRad = (d: number) => (d * Math.PI) / 180;
  const dLat = toRad(lat2 - lat1);
  const dLon = toRad(lon2 - lon1);
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLon / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

export function mapUrl(lat: number, lon: number): string {
  return `https://www.openstreetmap.org/?mlat=${lat}&mlon=${lon}#map=18/${lat}/${lon}`;
}

export function verifyUrl(name: string, address: string): string {
  return `https://www.google.com/search?q=${encodeURIComponent(`${name} ${address}`.trim())}`;
}

const UA = "RestaurantFinder/1.0 (personal lead-finding tool)";
export const HEADERS = { "User-Agent": UA, Accept: "application/json" };

export interface Center {
  lat: number;
  lon: number;
  label: string;
}

/** Turn a city, ZIP code or address into coordinates using OpenStreetMap's free Nominatim service. */
export async function geocode(query: string): Promise<Center | null> {
  const isZip = /^\d{5}(-\d{4})?$/.test(query.trim());
  const params = new URLSearchParams({ q: query, format: "jsonv2", limit: "1" });
  if (isZip) params.set("countrycodes", "us");
  const res = await fetch(`https://nominatim.openstreetmap.org/search?${params}`, {
    headers: HEADERS,
    cache: "no-store"
  });
  if (!res.ok) throw new Error("The location lookup service is busy. Try again in a minute.");
  const data = (await res.json()) as Array<{ lat: string; lon: string; display_name: string }>;
  if (!data.length) return null;
  return { lat: parseFloat(data[0].lat), lon: parseFloat(data[0].lon), label: data[0].display_name };
}
