import { neon } from "@neondatabase/serverless";

export class DbNotConfigured extends Error {}

let ready: Promise<void> | null = null;

export function sql() {
  const url = process.env.DATABASE_URL;
  if (!url) {
    throw new DbNotConfigured(
      "The database is not connected yet. In Vercel, open the Storage tab and add a Neon Postgres database."
    );
  }
  return neon(url);
}

/** Creates the table the first time it is needed. Safe to run many times. */
export async function ensureTable() {
  if (!ready) {
    const q = sql();
    ready = q`
      CREATE TABLE IF NOT EXISTS leads (
        id SERIAL PRIMARY KEY,
        visitor_id TEXT NOT NULL,
        place_key TEXT NOT NULL,
        name TEXT NOT NULL,
        category TEXT NOT NULL DEFAULT '',
        address TEXT NOT NULL DEFAULT '',
        phone TEXT NOT NULL DEFAULT '',
        website TEXT NOT NULL DEFAULT '',
        website_status TEXT NOT NULL DEFAULT 'none',
        lat DOUBLE PRECISION NOT NULL DEFAULT 0,
        lon DOUBLE PRECISION NOT NULL DEFAULT 0,
        source TEXT NOT NULL DEFAULT '',
        status TEXT NOT NULL DEFAULT 'New',
        notes TEXT NOT NULL DEFAULT '',
        created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
        UNIQUE (visitor_id, place_key)
      )
    `.then(() => undefined);
    ready.catch(() => {
      ready = null;
    });
  }
  await ready;
}
