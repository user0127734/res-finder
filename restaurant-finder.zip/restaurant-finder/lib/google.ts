import { classifyWebsite } from "./classify";
import { haversineMiles, mapUrl, verifyUrl } from "./geo";
import type { Place } from "./types";

export function googleConfigured(): boolean {
  return !!process.env.GOOGLE_MAPS_API_KEY;
}

const TYPE_QUERY: Record<string, string> = {
  all: "restaurants and food businesses",
  restaurant: "restaurants",
  cafe: "cafes",
  bakery: "bakeries",
  fast_food: "fast food restaurants",
  bar: "bars and pubs",
  ice_cream: "ice cream shops"
};

interface GPlace {
  id: string;
  displayName?: { text: string };
  formattedAddress?: string;
  nationalPhoneNumber?: string;
  websiteUri?: string;
  rating?: number;
  userRatingCount?: number;
  location?: { latitude: number; longitude: number };
  primaryTypeDisplayName?: { text: string };
}

/** Google Places (New) Text Search. Up to 3 pages (60 results) per search to keep costs predictable. */
export async function searchGoogle(
  lat: number,
  lon: number,
  radiusMiles: number,
  category: string
): Promise<Place[]> {
  const key = process.env.GOOGLE_MAPS_API_KEY;
  if (!key) throw new Error("Google Places is not set up yet. Add GOOGLE_MAPS_API_KEY in Vercel.");
  const fields = [
    "places.id",
    "places.displayName",
    "places.formattedAddress",
    "places.nationalPhoneNumber",
    "places.websiteUri",
    "places.rating",
    "places.userRatingCount",
    "places.location",
    "places.primaryTypeDisplayName",
    "nextPageToken"
  ].join(",");

  const all: GPlace[] = [];
  let pageToken: string | undefined;
  for (let page = 0; page < 3; page++) {
    const body: Record<string, unknown> = {
      textQuery: TYPE_QUERY[category] || TYPE_QUERY.all,
      pageSize: 20,
      locationBias: {
        circle: { center: { latitude: lat, longitude: lon }, radius: Math.min(radiusMiles * 1609.344, 50000) }
      }
    };
    if (pageToken) body.pageToken = pageToken;
    const res = await fetch("https://places.googleapis.com/v1/places:searchText", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "X-Goog-Api-Key": key,
        "X-Goog-FieldMask": fields
      },
      body: JSON.stringify(body),
      cache: "no-store"
    });
    if (!res.ok) {
      if (res.status === 403 || res.status === 400) {
        throw new Error(
          "Google rejected the key. Check that Places API (New) is enabled and the key is correct."
        );
      }
      throw new Error(`Google Places returned an error (${res.status}).`);
    }
    const json = (await res.json()) as { places?: GPlace[]; nextPageToken?: string };
    all.push(...(json.places || []));
    pageToken = json.nextPageToken;
    if (!pageToken) break;
  }

  const seen = new Set<string>();
  const out: Place[] = [];
  for (const g of all) {
    if (!g.location || !g.displayName?.text || seen.has(g.id)) continue;
    seen.add(g.id);
    const dist = haversineMiles(lat, lon, g.location.latitude, g.location.longitude);
    if (dist > radiusMiles + 0.5) continue;
    const cls = classifyWebsite(g.websiteUri, false);
    out.push({
      key: `google:${g.id}`,
      source: "google",
      name: g.displayName.text,
      category: g.primaryTypeDisplayName?.text || "Food business",
      address: g.formattedAddress || "",
      phone: g.nationalPhoneNumber || "",
      website: cls.url,
      websiteStatus: cls.status,
      websiteNote: cls.note,
      rating: g.rating ?? null,
      reviewCount: g.userRatingCount ?? null,
      lat: g.location.latitude,
      lon: g.location.longitude,
      distanceMiles: Math.round(dist * 10) / 10,
      mapUrl: mapUrl(g.location.latitude, g.location.longitude),
      verifyUrl: verifyUrl(g.displayName.text, g.formattedAddress || "")
    });
  }
  return out;
}
