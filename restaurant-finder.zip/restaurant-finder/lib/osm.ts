import { classifyWebsite } from "./classify";
import { HEADERS, haversineMiles, mapUrl, verifyUrl } from "./geo";
import type { Place } from "./types";

const ENDPOINTS = [
  "https://overpass-api.de/api/interpreter",
  "https://overpass.kumi.systems/api/interpreter"
];

const AMENITY: Record<string, string> = {
  all: "restaurant|cafe|fast_food|bar|pub|food_court|ice_cream|biergarten",
  restaurant: "restaurant|food_court",
  cafe: "cafe",
  fast_food: "fast_food",
  bar: "bar|pub|biergarten",
  ice_cream: "ice_cream",
  bakery: ""
};
const SHOP: Record<string, string> = {
  all: "bakery|pastry|deli|confectionery",
  bakery: "bakery|pastry",
  restaurant: "",
  cafe: "",
  fast_food: "",
  bar: "",
  ice_cream: ""
};

function labelFor(tags: Record<string, string>): string {
  const t = tags.amenity || tags.shop || "";
  const map: Record<string, string> = {
    restaurant: "Restaurant",
    cafe: "Cafe",
    fast_food: "Fast food",
    bar: "Bar",
    pub: "Pub",
    food_court: "Food court",
    ice_cream: "Ice cream",
    biergarten: "Beer garden",
    bakery: "Bakery",
    pastry: "Bakery",
    deli: "Deli",
    confectionery: "Confectionery"
  };
  const base = map[t] || "Food business";
  const cuisine = tags.cuisine ? ` · ${tags.cuisine.split(";")[0].replace(/_/g, " ")}` : "";
  return base + cuisine;
}

function addressOf(tags: Record<string, string>): string {
  const street = [tags["addr:housenumber"], tags["addr:street"]].filter(Boolean).join(" ");
  const parts = [street, tags["addr:city"], tags["addr:state"], tags["addr:postcode"]].filter(Boolean);
  return parts.join(", ");
}

interface OsmElement {
  type: "node" | "way" | "relation";
  id: number;
  lat?: number;
  lon?: number;
  center?: { lat: number; lon: number };
  tags?: Record<string, string>;
}

export async function searchOsm(
  lat: number,
  lon: number,
  radiusMiles: number,
  category: string
): Promise<Place[]> {
  const meters = Math.round(radiusMiles * 1609.344);
  const amenity = AMENITY[category] ?? AMENITY.all;
  const shop = SHOP[category] ?? "";
  const parts: string[] = [];
  if (amenity) parts.push(`nwr["amenity"~"^(${amenity})$"]["name"](around:${meters},${lat},${lon});`);
  if (shop) parts.push(`nwr["shop"~"^(${shop})$"]["name"](around:${meters},${lat},${lon});`);
  const query = `[out:json][timeout:40];(${parts.join("")});out center tags 2000;`;

  let lastError = "The map data service did not respond.";
  for (const endpoint of ENDPOINTS) {
    try {
      const res = await fetch(endpoint, {
        method: "POST",
        headers: { ...HEADERS, "Content-Type": "application/x-www-form-urlencoded" },
        body: `data=${encodeURIComponent(query)}`,
        cache: "no-store"
      });
      if (!res.ok) {
        lastError = `The map data service returned an error (${res.status}). Try a smaller distance.`;
        continue;
      }
      const json = (await res.json()) as { elements?: OsmElement[] };
      return toPlaces(json.elements || [], lat, lon, radiusMiles);
    } catch {
      lastError = "Could not reach the map data service. Try again in a minute.";
    }
  }
  throw new Error(lastError);
}

function toPlaces(elements: OsmElement[], lat: number, lon: number, radiusMiles: number): Place[] {
  const seen = new Set<string>();
  const out: Place[] = [];
  for (const el of elements) {
    const tags = el.tags || {};
    const plat = el.lat ?? el.center?.lat;
    const plon = el.lon ?? el.center?.lon;
    if (!tags.name || plat == null || plon == null) continue;
    const key = `osm:${el.type}:${el.id}`;
    if (seen.has(key)) continue;
    // Remove duplicates: same name at (almost) the same spot
    const dupKey = `${tags.name.toLowerCase()}|${plat.toFixed(3)}|${plon.toFixed(3)}`;
    if (seen.has(dupKey)) continue;
    seen.add(key);
    seen.add(dupKey);

    const distance = haversineMiles(lat, lon, plat, plon);
    if (distance > radiusMiles + 0.5) continue;

    const rawSite = tags.website || tags["contact:website"] || tags.url || "";
    const socialOnly = !rawSite && !!(tags["contact:facebook"] || tags["contact:instagram"] || tags.facebook || tags.instagram);
    const cls = classifyWebsite(rawSite, socialOnly);
    const address = addressOf(tags);
    out.push({
      key,
      source: "osm",
      name: tags.name,
      category: labelFor(tags),
      address,
      phone: tags.phone || tags["contact:phone"] || "",
      website: cls.url,
      websiteStatus: cls.status,
      websiteNote: cls.note,
      rating: null,
      reviewCount: null,
      lat: plat,
      lon: plon,
      distanceMiles: Math.round(distance * 10) / 10,
      mapUrl: mapUrl(plat, plon),
      verifyUrl: verifyUrl(tags.name, address)
    });
  }
  return out;
}
