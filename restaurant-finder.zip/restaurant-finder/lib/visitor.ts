import { cookies } from "next/headers";
import { randomUUID } from "crypto";

const NAME = "rf_visitor";

/** Anonymous per-browser ID so each visitor only sees their own saved leads. No sign-up needed. */
export function getVisitorId(): string {
  const jar = cookies();
  const existing = jar.get(NAME)?.value;
  if (existing && /^[0-9a-f-]{36}$/.test(existing)) return existing;
  const id = randomUUID();
  jar.set(NAME, id, {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    path: "/",
    maxAge: 60 * 60 * 24 * 365 * 2
  });
  return id;
}
