export type WebsiteStatus = "none" | "found" | "verify";

export interface Place {
  key: string; // stable id, e.g. "osm:node:123" or "google:ChIJ..."
  source: "osm" | "google";
  name: string;
  category: string;
  address: string;
  phone: string;
  website: string;
  websiteStatus: WebsiteStatus;
  websiteNote: string;
  rating: number | null;
  reviewCount: number | null;
  lat: number;
  lon: number;
  distanceMiles: number;
  mapUrl: string;
  verifyUrl: string;
}

export const LEAD_STATUSES = [
  "New",
  "Ready to contact",
  "Contacted",
  "Interested",
  "Client won",
  "Not interested"
] as const;
export type LeadStatus = (typeof LEAD_STATUSES)[number];

export interface Lead {
  id: number;
  place_key: string;
  name: string;
  category: string;
  address: string;
  phone: string;
  website: string;
  website_status: WebsiteStatus;
  lat: number;
  lon: number;
  source: string;
  status: LeadStatus;
  notes: string;
  created_at: string;
}

export const CATEGORIES = [
  { value: "all", label: "All food businesses" },
  { value: "restaurant", label: "Restaurants" },
  { value: "cafe", label: "Cafes" },
  { value: "bakery", label: "Bakeries" },
  { value: "fast_food", label: "Fast food" },
  { value: "bar", label: "Bars and pubs" },
  { value: "ice_cream", label: "Ice cream" }
] as const;

export const OSM_MAX_MILES = 50;
export const GOOGLE_MAX_MILES = 31;
