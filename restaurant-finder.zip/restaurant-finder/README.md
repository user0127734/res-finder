# Restaurant Finder: setup guide (no installs needed)

You only need a web browser. Total time: about 15 minutes.

## Part 1: Put the files on GitHub
1. Unzip `restaurant-finder.zip` on your computer (right-click, Extract All).
2. Go to github.com, click the **+** at the top right, then **New repository**.
3. Name it `restaurant-finder`, choose **Private**, click **Create repository**.
4. On the new page click **uploading an existing file**.
5. Open the unzipped folder, select everything INSIDE it (not the folder itself), and drag it into the GitHub page.
   Make sure the `app`, `lib`, and `components` folders appear in the list.
6. Click **Commit changes**.

## Part 2: Publish with Vercel (free)
1. Go to vercel.com and click **Sign Up**, then **Continue with GitHub**.
2. Click **Add New... > Project**, find `restaurant-finder`, click **Import**.
3. Leave every setting as it is and click **Deploy**. Wait about 1-2 minutes.
   (Searching will work after this step. Saving leads needs Part 3.)

## Part 3: Add the free database (for My Leads)
1. In your Vercel project, open the **Storage** tab.
2. Choose **Neon (Postgres)** from the marketplace, accept the free plan, and connect it to your project.
   This adds the DATABASE_URL setting for you.
3. Open the **Deployments** tab, click the three dots on the latest one, and choose **Redeploy**.

## Part 4 (optional, later): Turn on Google Places
Google Places gives better phone, rating, and website data, but needs a card on file.
1. In Google Cloud Console, create a project and enable **Places API (New)**.
2. Set a budget alert and a daily quota cap on that API before creating the key.
3. Create an API key and restrict it to Places API (New).
4. In Vercel: Settings > Environment Variables > add `GOOGLE_MAPS_API_KEY`, then Redeploy.
Never paste the key into the chat or into GitHub.

## Good to know
- Free OpenStreetMap searches cover up to 50 miles at a time; Google up to 31 miles.
- A missing website in the data does NOT prove the business has none. Use "Check on Google" before contacting anyone.
- Google's terms limit how long its data may be stored; read them before saving many Google results.
- Leads belong to the browser you saved them in. Export a CSV regularly.
