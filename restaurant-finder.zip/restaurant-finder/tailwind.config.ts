import type { Config } from "tailwindcss";

const config: Config = {
  content: ["./app/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        ink: { 950: "#0c1519", 900: "#111d22", 800: "#182830", 700: "#223640", 600: "#2f4954" },
        paper: { 100: "#e9efe9", 300: "#b4c2bd", 500: "#7f918c" },
        amber: { 400: "#f0b24a", 500: "#e29b25" },
        sage: { 400: "#7fc3a6" },
        brick: { 400: "#e7826b" }
      },
      fontFamily: {
        display: ["var(--font-display)", "system-ui", "sans-serif"],
        body: ["var(--font-body)", "system-ui", "sans-serif"]
      }
    }
  },
  plugins: []
};
export default config;
