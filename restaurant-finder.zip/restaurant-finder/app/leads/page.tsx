"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import StatusBadge from "@/components/StatusBadge";
import { LEAD_STATUSES, type Lead } from "@/lib/types";

export default function LeadsPage() {
  const [leads, setLeads] = useState<Lead[] | null>(null);
  const [error, setError] = useState("");
  const [query, setQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");

  const load = useCallback(async () => {
    try {
      const res = await fetch("/api/leads");
      const j = await res.json();
      if (!res.ok) throw new Error(j.error || "Could not load your leads.");
      setLeads(j.leads);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Could not load your leads.");
      setLeads([]);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  async function patch(id: number, body: Record<string, string>) {
    const res = await fetch(`/api/leads/${id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body)
    });
    if (!res.ok) {
      setError("Could not save that change. Try again.");
      return;
    }
    setError("");
    setLeads((ls) => ls && ls.map((l) => (l.id === id ? { ...l, ...body } as Lead : l)));
  }

  async function remove(id: number) {
    if (!confirm("Remove this lead?")) return;
    const res = await fetch(`/api/leads/${id}`, { method: "DELETE" });
    if (res.ok) setLeads((ls) => ls && ls.filter((l) => l.id !== id));
    else setError("Could not remove that lead. Try again.");
  }

  const shown = useMemo(() => {
    const q = query.trim().toLowerCase();
    return (leads || []).filter(
      (l) =>
        (statusFilter === "all" || l.status === statusFilter) &&
        (!q || [l.name, l.address, l.phone, l.notes, l.category].some((v) => v.toLowerCase().includes(q)))
    );
  }, [leads, query, statusFilter]);

  return (
    <div>
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="font-display text-3xl font-bold">My Leads</h1>
          <p className="mt-1 text-paper-300">
            Saved on this browser&apos;s private list. Clearing your browser cookies would disconnect you from it,
            so export a CSV now and then.
          </p>
        </div>
        <a className="btn btn-quiet" href="/api/leads/export">Export CSV</a>
      </div>

      <div className="mt-5 grid gap-3 sm:grid-cols-3">
        <div className="sm:col-span-2">
          <label htmlFor="q" className="label">Search your leads</label>
          <input id="q" className="field" placeholder="Name, address, phone, or notes" value={query} onChange={(e) => setQuery(e.target.value)} />
        </div>
        <div>
          <label htmlFor="sf" className="label">Status</label>
          <select id="sf" className="field" value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)}>
            <option value="all">All statuses</option>
            {LEAD_STATUSES.map((s) => (
              <option key={s} value={s}>{s}</option>
            ))}
          </select>
        </div>
      </div>

      {error && (
        <div role="alert" className="mt-5 rounded-lg border border-brick-400/50 bg-brick-400/10 p-4 text-brick-400">
          {error}
        </div>
      )}

      {leads === null ? (
        <p className="mt-6 text-paper-300">Loading your leads...</p>
      ) : shown.length === 0 ? (
        <p className="mt-6 text-paper-300">
          {leads.length === 0 ? "No saved leads yet. Run a search and click Save lead on a business." : "No leads match your search."}
        </p>
      ) : (
        <ul className="mt-6 space-y-3">
          {shown.map((l) => (
            <li key={l.id} className="rounded-xl border border-ink-700 bg-ink-800 p-4">
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div>
                  <h2 className="font-display text-xl font-bold">{l.name}</h2>
                  <p className="text-paper-300">{l.category}</p>
                </div>
                <StatusBadge status={l.website_status} />
              </div>
              <p className="mt-2 text-paper-300">
                {l.address || "No address"} · {l.phone || "No phone"}
              </p>
              {l.website && (
                <p className="break-all text-paper-300">
                  <a className="text-sage-400 underline" href={l.website} target="_blank" rel="noopener noreferrer">{l.website}</a>
                </p>
              )}
              <div className="mt-3 grid gap-3 sm:grid-cols-3">
                <div>
                  <label htmlFor={`s${l.id}`} className="label">Status</label>
                  <select id={`s${l.id}`} className="field" value={l.status} onChange={(e) => patch(l.id, { status: e.target.value })}>
                    {LEAD_STATUSES.map((s) => (
                      <option key={s} value={s}>{s}</option>
                    ))}
                  </select>
                </div>
                <div className="sm:col-span-2">
                  <label htmlFor={`n${l.id}`} className="label">Notes (saved when you click away)</label>
                  <textarea
                    id={`n${l.id}`}
                    className="field"
                    rows={2}
                    defaultValue={l.notes}
                    onBlur={(e) => e.target.value !== l.notes && patch(l.id, { notes: e.target.value })}
                  />
                </div>
              </div>
              <div className="mt-3 flex flex-wrap gap-2">
                <a className="btn btn-quiet !py-2" href={`https://www.openstreetmap.org/?mlat=${l.lat}&mlon=${l.lon}#map=18/${l.lat}/${l.lon}`} target="_blank" rel="noopener noreferrer">View on map</a>
                <a className="btn btn-quiet !py-2" href={`https://www.google.com/search?q=${encodeURIComponent(l.name + " " + l.address)}`} target="_blank" rel="noopener noreferrer">Check on Google</a>
                <button className="btn btn-quiet !py-2 text-brick-400" onClick={() => remove(l.id)}>Remove</button>
              </div>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
