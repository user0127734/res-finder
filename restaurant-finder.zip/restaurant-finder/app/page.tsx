"use client";

import { useEffect, useMemo, useState } from "react";
import StatusBadge from "@/components/StatusBadge";
import { CATEGORIES, OSM_MAX_MILES, type Place, type WebsiteStatus } from "@/lib/types";

type Filter = "potential" | "verify" | "found" | "all";

interface SearchResponse {
  center: { lat: number; lon: number; label: string };
  total: number;
  results: Place[];
  warnings: string[];
  radiusMiles: number;
  source: string;
}

export default function SearchPage() {
  const [location, setLocation] = useState("");
  const [coords, setCoords] = useState<{ lat: number; lon: number } | null>(null);
  const [radius, setRadius] = useState("25");
  const [category, setCategory] = useState("all");
  const [source, setSource] = useState<"osm" | "google">("osm");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [data, setData] = useState<SearchResponse | null>(null);
  const [filter, setFilter] = useState<Filter>("potential");
  const [saved, setSaved] = useState<Set<string>>(new Set());
  const [saveError, setSaveError] = useState("");
  const [locating, setLocating] = useState(false);

  useEffect(() => {
    fetch("/api/leads")
      .then((r) => (r.ok ? r.json() : { leads: [] }))
      .then((j) => setSaved(new Set((j.leads || []).map((l: { place_key: string }) => l.place_key))))
      .catch(() => undefined);
  }, []);

  function useMyLocation() {
    setError("");
    if (!navigator.geolocation) {
      setError("Your browser cannot share your location. Type a city or ZIP code instead.");
      return;
    }
    setLocating(true);
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setCoords({ lat: pos.coords.latitude, lon: pos.coords.longitude });
        setLocation("Current location");
        setLocating(false);
      },
      () => {
        setLocating(false);
        setError("Location permission was denied. Type a city or ZIP code instead.");
      },
      { timeout: 10000 }
    );
  }

  async function search(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    setSaveError("");
    setLoading(true);
    setData(null);
    try {
      const res = await fetch("/api/search", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          location: coords ? "" : location,
          lat: coords?.lat,
          lon: coords?.lon,
          radiusMiles: Number(radius),
          category,
          source
        })
      });
      const json = await res.json();
      if (!res.ok) throw new Error(json.error || "Search failed.");
      setData(json);
      setFilter("potential");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Search failed.");
    } finally {
      setLoading(false);
    }
  }

  async function save(p: Place) {
    setSaveError("");
    const res = await fetch("/api/leads", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(p)
    });
    if (res.ok) {
      setSaved((s) => new Set(s).add(p.key));
    } else {
      const j = await res.json().catch(() => ({}));
      setSaveError(j.error || "Could not save this lead.");
    }
  }

  const counts = useMemo(() => {
    const c: Record<WebsiteStatus, number> = { none: 0, verify: 0, found: 0 };
    data?.results.forEach((r) => c[r.websiteStatus]++);
    return c;
  }, [data]);

  const shown = useMemo(() => {
    if (!data) return [];
    if (filter === "all") return data.results;
    if (filter === "potential") return data.results.filter((r) => r.websiteStatus === "none");
    return data.results.filter((r) => r.websiteStatus === filter);
  }, [data, filter]);

  const tabs: { id: Filter; label: string; n: number }[] = data
    ? [
        { id: "potential", label: "Potential Clients", n: counts.none },
        { id: "verify", label: "Needs verification", n: counts.verify },
        { id: "found", label: "Website found", n: counts.found },
        { id: "all", label: "Everything", n: data.total }
      ]
    : [];

  return (
    <div>
      <h1 className="font-display text-3xl font-bold sm:text-4xl">Find food businesses with no website</h1>
      <p className="mt-2 max-w-xl text-paper-300">
        Enter a place and a distance. Businesses with no website on record come first, so you can check
        them and reach out.
      </p>

      <form onSubmit={search} className="mt-6 rounded-xl border border-ink-700 bg-ink-800 p-4 sm:p-5">
        <div className="grid gap-4 sm:grid-cols-6">
          <div className="sm:col-span-4">
            <label htmlFor="loc" className="label">City, ZIP code, or address</label>
            <input
              id="loc"
              className="field"
              placeholder="Atlanta, GA  or  30297"
              value={location}
              onChange={(e) => {
                setLocation(e.target.value);
                setCoords(null);
              }}
            />
          </div>
          <div className="flex items-end sm:col-span-2">
            <button type="button" className="btn btn-quiet w-full" onClick={useMyLocation} disabled={locating}>
              {locating ? "Finding you..." : "Use my current location"}
            </button>
          </div>
          <div className="sm:col-span-2">
            <label htmlFor="rad" className="label">Distance in miles</label>
            <input
              id="rad"
              className="field"
              type="number"
              min={1}
              max={300}
              inputMode="numeric"
              value={radius}
              onChange={(e) => setRadius(e.target.value)}
            />
          </div>
          <div className="sm:col-span-2">
            <label htmlFor="cat" className="label">Business type</label>
            <select id="cat" className="field" value={category} onChange={(e) => setCategory(e.target.value)}>
              {CATEGORIES.map((c) => (
                <option key={c.value} value={c.value}>{c.label}</option>
              ))}
            </select>
          </div>
          <div className="sm:col-span-2">
            <label htmlFor="src" className="label">Data source</label>
            <select id="src" className="field" value={source} onChange={(e) => setSource(e.target.value as "osm" | "google")}>
              <option value="osm">OpenStreetMap (free)</option>
              <option value="google">Google Places (needs key)</option>
            </select>
          </div>
        </div>
        <button type="submit" className="btn btn-primary mt-5 w-full sm:w-auto" disabled={loading}>
          {loading ? "Searching..." : "Search Restaurants"}
        </button>
        <p className="mt-3 text-sm text-paper-500">
          Free OpenStreetMap searches cover up to {OSM_MAX_MILES} miles at a time.
        </p>
      </form>

      {error && (
        <div role="alert" className="mt-5 rounded-lg border border-brick-400/50 bg-brick-400/10 p-4 text-brick-400">
          {error}
        </div>
      )}

      {loading && <p className="mt-6 text-paper-300">Searching. Big areas can take up to 30 seconds.</p>}

      {data && (
        <section className="mt-8" aria-live="polite">
          <p className="text-lg">
            <strong>{data.total}</strong> food businesses within {data.radiusMiles} miles of{" "}
            <span className="text-paper-300">{data.center.label.split(",").slice(0, 2).join(",")}</span>.{" "}
            <strong className="text-amber-400">{counts.none}</strong> have no website listed.
          </p>
          {data.warnings.map((w) => (
            <p key={w} className="mt-2 text-sm text-paper-500">{w}</p>
          ))}

          <div role="tablist" className="mt-5 flex flex-wrap gap-2">
            {tabs.map((t) => (
              <button
                key={t.id}
                role="tab"
                aria-selected={filter === t.id}
                onClick={() => setFilter(t.id)}
                className={`btn !py-2 ${filter === t.id ? "btn-primary" : "btn-quiet"}`}
              >
                {t.label} ({t.n})
              </button>
            ))}
          </div>

          {saveError && (
            <div role="alert" className="mt-4 rounded-lg border border-brick-400/50 bg-brick-400/10 p-3 text-brick-400">
              {saveError}
            </div>
          )}

          {shown.length === 0 ? (
            <p className="mt-6 text-paper-300">
              Nothing in this group. Try another tab, a bigger distance, or a different business type.
            </p>
          ) : (
            <ul className="mt-5 space-y-3">
              {shown.map((p) => (
                <li key={p.key} className="rounded-xl border border-ink-700 bg-ink-800 p-4">
                  <div className="flex flex-wrap items-start justify-between gap-3">
                    <div className="min-w-0">
                      <h2 className="font-display text-xl font-bold">{p.name}</h2>
                      <p className="text-paper-300">{p.category}</p>
                    </div>
                    <StatusBadge status={p.websiteStatus} />
                  </div>
                  <dl className="mt-3 grid gap-x-6 gap-y-1 text-paper-300 sm:grid-cols-2">
                    <div><dt className="inline text-paper-500">Address: </dt><dd className="inline">{p.address || "Not listed"}</dd></div>
                    <div><dt className="inline text-paper-500">Distance: </dt><dd className="inline">{p.distanceMiles} miles</dd></div>
                    <div><dt className="inline text-paper-500">Phone: </dt><dd className="inline">{p.phone || "Not listed"}</dd></div>
                    {p.rating != null && (
                      <div><dt className="inline text-paper-500">Rating: </dt><dd className="inline">{p.rating} ({p.reviewCount ?? 0} reviews)</dd></div>
                    )}
                    {p.website && (
                      <div className="sm:col-span-2 break-all">
                        <dt className="inline text-paper-500">Website: </dt>
                        <dd className="inline"><a className="text-sage-400 underline" href={p.website} target="_blank" rel="noopener noreferrer">{p.website}</a></dd>
                      </div>
                    )}
                  </dl>
                  <p className="mt-2 text-sm text-paper-500">{p.websiteNote}</p>
                  <div className="mt-4 flex flex-wrap gap-2">
                    <button
                      className={`btn !py-2 ${saved.has(p.key) ? "btn-quiet" : "btn-primary"}`}
                      onClick={() => save(p)}
                      disabled={saved.has(p.key)}
                    >
                      {saved.has(p.key) ? "Saved to My Leads" : "Save lead"}
                    </button>
                    <a className="btn btn-quiet !py-2" href={p.mapUrl} target="_blank" rel="noopener noreferrer">View on map</a>
                    <a className="btn btn-quiet !py-2" href={p.verifyUrl} target="_blank" rel="noopener noreferrer">Check on Google</a>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </section>
      )}
    </div>
  );
}
