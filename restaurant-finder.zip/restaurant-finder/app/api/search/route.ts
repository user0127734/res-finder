import { NextRequest, NextResponse } from "next/server";
import { geocode } from "@/lib/geo";
import { searchOsm } from "@/lib/osm";
import { googleConfigured, searchGoogle } from "@/lib/google";
import { allow } from "@/lib/ratelimit";
import { CATEGORIES, GOOGLE_MAX_MILES, OSM_MAX_MILES, type Place } from "@/lib/types";

export const maxDuration = 60;

const ORDER = { none: 0, verify: 1, found: 2 } as const;

export async function POST(req: NextRequest) {
  const ip = req.headers.get("x-forwarded-for")?.split(",")[0].trim() || "unknown";
  if (!allow(`search:${ip}`, 15, 10 * 60 * 1000)) {
    return NextResponse.json(
      { error: "You have searched a lot in a short time. Wait a few minutes and try again." },
      { status: 429 }
    );
  }

  let body: Record<string, unknown>;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Invalid request." }, { status: 400 });
  }

  const location = typeof body.location === "string" ? body.location.trim().slice(0, 200) : "";
  const lat = typeof body.lat === "number" ? body.lat : null;
  const lon = typeof body.lon === "number" ? body.lon : null;
  const radius = Number(body.radiusMiles);
  const category = typeof body.category === "string" ? body.category : "all";
  const source = body.source === "google" ? "google" : "osm";

  if (!Number.isFinite(radius) || radius < 1 || radius > 300) {
    return NextResponse.json({ error: "Enter a distance between 1 and 300 miles." }, { status: 400 });
  }
  if (!CATEGORIES.some((c) => c.value === category)) {
    return NextResponse.json({ error: "Pick a business category from the list." }, { status: 400 });
  }

  const warnings: string[] = [];
  let effectiveRadius = radius;
  const max = source === "google" ? GOOGLE_MAX_MILES : OSM_MAX_MILES;
  if (radius > max) {
    effectiveRadius = max;
    warnings.push(
      `${source === "google" ? "Google" : "OpenStreetMap"} searches are limited to ${max} miles here, so I searched ${max} miles instead of ${radius}. For a bigger area, run several searches in different towns.`
    );
  }

  if (source === "google" && !googleConfigured()) {
    return NextResponse.json(
      {
        error:
          "Google Places is not turned on yet. Choose OpenStreetMap, or add a Google key in Vercel (see the setup guide)."
      },
      { status: 400 }
    );
  }

  try {
    let center: { lat: number; lon: number; label: string };
    if (lat != null && lon != null && Math.abs(lat) <= 90 && Math.abs(lon) <= 180) {
      center = { lat, lon, label: "Your current location" };
    } else {
      if (!location) {
        return NextResponse.json(
          { error: "Enter a city, ZIP code, or address, or use your current location." },
          { status: 400 }
        );
      }
      const found = await geocode(location);
      if (!found) {
        return NextResponse.json(
          { error: `I could not find "${location}". Try a city and state, or a ZIP code.` },
          { status: 404 }
        );
      }
      center = found;
    }

    const places: Place[] =
      source === "google"
        ? await searchGoogle(center.lat, center.lon, effectiveRadius, category)
        : await searchOsm(center.lat, center.lon, effectiveRadius, category);

    places.sort(
      (a, b) =>
        ORDER[a.websiteStatus] - ORDER[b.websiteStatus] || a.distanceMiles - b.distanceMiles
    );

    if (source === "osm") {
      warnings.push(
        "OpenStreetMap is built by volunteers, so some businesses are missing and many have no phone or website recorded. A missing website here does not prove the business has none."
      );
    } else if (places.length >= 55) {
      warnings.push("Google returns at most 60 results per search. Try a smaller distance to see more.");
    }

    return NextResponse.json({
      center,
      source,
      radiusMiles: effectiveRadius,
      total: places.length,
      results: places,
      warnings
    });
  } catch (e) {
    const message = e instanceof Error ? e.message : "Something went wrong. Try again.";
    return NextResponse.json({ error: message }, { status: 502 });
  }
}
