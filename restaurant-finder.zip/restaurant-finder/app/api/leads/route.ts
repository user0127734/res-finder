import { NextRequest, NextResponse } from "next/server";
import { DbNotConfigured, ensureTable, sql } from "@/lib/db";
import { getVisitorId } from "@/lib/visitor";

function fail(e: unknown) {
  const message = e instanceof Error ? e.message : "Database error.";
  return NextResponse.json({ error: message }, { status: e instanceof DbNotConfigured ? 503 : 500 });
}

export async function GET() {
  try {
    await ensureTable();
    const visitor = getVisitorId();
    const rows = await sql()`SELECT * FROM leads WHERE visitor_id = ${visitor} ORDER BY created_at DESC`;
    return NextResponse.json({ leads: rows });
  } catch (e) {
    return fail(e);
  }
}

const s = (v: unknown, max = 500) => (typeof v === "string" ? v.slice(0, max) : "");

export async function POST(req: NextRequest) {
  try {
    const b = await req.json();
    const key = s(b.key, 200);
    const name = s(b.name, 200);
    if (!key || !name) return NextResponse.json({ error: "Missing business details." }, { status: 400 });
    const status = ["none", "found", "verify"].includes(b.websiteStatus) ? b.websiteStatus : "none";
    const lat = Number(b.lat) || 0;
    const lon = Number(b.lon) || 0;

    await ensureTable();
    const visitor = getVisitorId();
    const q = sql();
    const count = await q`SELECT count(*)::int AS n FROM leads WHERE visitor_id = ${visitor}`;
    if (count[0].n >= 2000) {
      return NextResponse.json({ error: "You reached the 2,000 saved leads limit." }, { status: 400 });
    }
    await q`
      INSERT INTO leads (visitor_id, place_key, name, category, address, phone, website, website_status, lat, lon, source)
      VALUES (${visitor}, ${key}, ${name}, ${s(b.category, 100)}, ${s(b.address)}, ${s(b.phone, 50)},
              ${s(b.website)}, ${status}, ${lat}, ${lon}, ${s(b.source, 20)})
      ON CONFLICT (visitor_id, place_key) DO NOTHING
    `;
    return NextResponse.json({ ok: true });
  } catch (e) {
    return fail(e);
  }
}
