import { NextRequest, NextResponse } from "next/server";
import { DbNotConfigured, ensureTable, sql } from "@/lib/db";
import { getVisitorId } from "@/lib/visitor";
import { LEAD_STATUSES } from "@/lib/types";

function fail(e: unknown) {
  const message = e instanceof Error ? e.message : "Database error.";
  return NextResponse.json({ error: message }, { status: e instanceof DbNotConfigured ? 503 : 500 });
}

export async function PATCH(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const id = Number(params.id);
    if (!Number.isInteger(id)) return NextResponse.json({ error: "Bad id." }, { status: 400 });
    const b = await req.json();
    await ensureTable();
    const visitor = getVisitorId();
    const q = sql();
    if (typeof b.status === "string") {
      if (!(LEAD_STATUSES as readonly string[]).includes(b.status)) {
        return NextResponse.json({ error: "Unknown status." }, { status: 400 });
      }
      await q`UPDATE leads SET status = ${b.status} WHERE id = ${id} AND visitor_id = ${visitor}`;
    }
    if (typeof b.notes === "string") {
      await q`UPDATE leads SET notes = ${b.notes.slice(0, 5000)} WHERE id = ${id} AND visitor_id = ${visitor}`;
    }
    return NextResponse.json({ ok: true });
  } catch (e) {
    return fail(e);
  }
}

export async function DELETE(_req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const id = Number(params.id);
    if (!Number.isInteger(id)) return NextResponse.json({ error: "Bad id." }, { status: 400 });
    await ensureTable();
    const visitor = getVisitorId();
    await sql()`DELETE FROM leads WHERE id = ${id} AND visitor_id = ${visitor}`;
    return NextResponse.json({ ok: true });
  } catch (e) {
    return fail(e);
  }
}
