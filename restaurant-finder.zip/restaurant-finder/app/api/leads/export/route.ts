import { NextResponse } from "next/server";
import { ensureTable, sql } from "@/lib/db";
import { getVisitorId } from "@/lib/visitor";

export const dynamic = "force-dynamic";

// Prefix cells that start with =,+,-,@ so spreadsheets do not run them as formulas.
function cell(v: unknown): string {
  let t = String(v ?? "");
  if (/^[=+\-@\t\r]/.test(t)) t = `'${t}`;
  return `"${t.replace(/"/g, '""')}"`;
}

export async function GET() {
  try {
    await ensureTable();
    const visitor = getVisitorId();
    const rows = await sql()`SELECT * FROM leads WHERE visitor_id = ${visitor} ORDER BY created_at DESC`;
    const header = ["Name", "Category", "Address", "Phone", "Website", "Website status", "Status", "Notes", "Map link", "Saved on"];
    const lines = [header.map(cell).join(",")];
    for (const r of rows) {
      lines.push(
        [
          r.name,
          r.category,
          r.address,
          r.phone,
          r.website,
          r.website_status === "none" ? "No website listed" : r.website_status === "found" ? "Website found" : "Needs verification",
          r.status,
          r.notes,
          `https://www.openstreetmap.org/?mlat=${r.lat}&mlon=${r.lon}`,
          new Date(r.created_at).toISOString().slice(0, 10)
        ]
          .map(cell)
          .join(",")
      );
    }
    // BOM so Excel opens accents correctly
    return new NextResponse("\uFEFF" + lines.join("\r\n"), {
      headers: {
        "Content-Type": "text/csv; charset=utf-8",
        "Content-Disposition": 'attachment; filename="my-leads.csv"'
      }
    });
  } catch (e) {
    return NextResponse.json({ error: e instanceof Error ? e.message : "Export failed." }, { status: 500 });
  }
}
